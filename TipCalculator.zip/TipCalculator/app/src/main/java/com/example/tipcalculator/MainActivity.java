package com.example.tipcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.lang.Math;

public class MainActivity extends AppCompatActivity {

    public String number = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) { // create view
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean onCreateOptionsMenu(Menu m) { // create activity menu
        MenuInflater inflate = getMenuInflater();
        inflate.inflate(R.menu.activity_menu, m);
        return true;
    }

    public void Add1(View v) { // add a number
        number+="1";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add2(View v) { // add a number
        number+="2";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add3(View v) { // add a number
        number+="3";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add4(View v) { // add a number
        number+="4";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add5(View v) { // add a number
        number+="5";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add6(View v) { // add a number
        number+="6";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add7(View v) { // add a number
        number+="7";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add8(View v) { // add a number
        number+="8";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add9(View v) { // add a number
        number+="9";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void Add0(View v) { // add a number
        number+="0";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }

    public void ClearNumber(View v) { // clear number
        number="";
        TextView input = (TextView)findViewById(R.id.textView);
        input.setText(number);
    }
    public void AddDecimal(View v) { // add a decimal
        if (!number.contains(".")) {
            number+=".";
            TextView input = (TextView)findViewById(R.id.textView);
            input.setText(number);
        }
    }


    public void Calculate10(View v) { // method for button
        TextView input = (TextView)findViewById(R.id.textView);
        TextView view = (TextView)findViewById(R.id.ResultView);

        if (!input.getText().equals("")) {
            String temp = input.getText().toString();
            if (temp.charAt(temp.length()-1) == '.') {
                temp += "0";
            }
            double d = Math.round(Double.valueOf(temp) * 0.1 * 100.0)/100.0;
            view.setText(Double.toString(d)); // changes text view item
        }
    }

    public void Calculate15(View v) { // method for other button
        TextView input = (TextView)findViewById(R.id.textView);
        TextView view = (TextView)findViewById(R.id.ResultView);
        if (!input.getText().equals("")) {
            String temp = input.getText().toString();
            if (temp.charAt(temp.length() - 1) == '.') {
                temp += "0";
            }
            double d = Math.round(Double.valueOf(temp) * 0.15 * 100.0) / 100.0; // accesses the text field
            view.setText(Double.toString(d)); // changes text view
        }
    }

    public void CalculateCustom(View v) { // method for calculating custom tip
        TextView input = (TextView)findViewById(R.id.textView);
        TextView view = (TextView)findViewById(R.id.ResultView);
        EditText percentEdit = (EditText)findViewById(R.id.PercentText);

        if (!percentEdit.getText().toString().isEmpty()) {
            double percent = Double.valueOf(percentEdit.getText().toString()); // access percent amount
            if (!input.getText().equals("")) {
                String temp = input.getText().toString();
                if (temp.charAt(temp.length() - 1) == '.') {
                    temp += "0";
                }
                double d = Math.round(Double.valueOf(temp) * percent * 0.01 * 100.0) / 100.0;
                view.setText(Double.toString(d)); // changes text field
            }
        }
    }

    public void exitApp(MenuItem item) { // exits app
        finish();
        System.exit(0);
    }
}
