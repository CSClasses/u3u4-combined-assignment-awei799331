/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alexanderwu3a1q5; // imports
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Collections;

/**
 * 
 * @author weia7993
 */
public class AlexPanel extends JPanel implements ActionListener {
    
    public Vector<String> array = new Vector<>(); // create objects
    public JList list = new JList(array);
    public JScrollPane scroll = new JScrollPane();
    
    public JTextField AddBox = new JTextField();
    public JButton AddButton = new JButton("Add item");
    public JButton SortButton = new JButton("Sort");
    public JTextField SearchBox = new JTextField();
    public JButton SearchButton = new JButton("Search for an entry");
    public JLabel FoundBox = new JLabel();
    
    public AlexPanel() { // constructor
        setLayout(null); // custom layout
        
        array.add("Tony"); // add item to array
        scroll.setViewportView(list); // put JList in scrollable viewport
        add(scroll);
        scroll.setBounds(10, 10, 300, 500);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        add(AddBox); // add items to jpanel
        AddBox.setBounds(450, 10, 150, 30); // set custom dimensions
        
        add(AddButton);
        AddButton.setBounds(600, 10, 100, 30);
        AddButton.addActionListener(this);
        
        SortButton.setBounds(720, 10, 100, 30);
        add(SortButton);
        SortButton.addActionListener(this);
        
        SearchBox.setBounds(450, 50, 150, 30);
        add(SearchBox);
        
        SearchButton.setBounds(600, 50, 150, 30);
        add(SearchButton);
        SearchButton.addActionListener(this);
        
        FoundBox.setBounds(600, 80, 250, 30);
        add(FoundBox);
        
        
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) { // button listeners
        JButton b = (JButton) e.getSource(); // get source of buttons
        if (b == AddButton) { // add item to list
            String temp;
            if (AddBox.getText() != null) { // if textbox isn't empty
                temp = AddBox.getText(); // add item
                array.add(temp);
                list.setListData(array);
            }
        } else if (b == SortButton) { // sort button pressed
            Collections.sort(array); // sort array
            list.setListData(array); // update JList
        } else if (b == SearchButton) { // search button
            if (SearchBox.getText() != null) { // search text box isn't empty
                String temp = SearchBox.getText(); // access text box
                if (array.contains(temp)) { // if the array las the item
                    FoundBox.setText(temp + " was found in the list."); // print result
                } else {
                    FoundBox.setText(temp + " was not found in the list.");
                }
            }
        }
    }
}
