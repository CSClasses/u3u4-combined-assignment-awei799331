/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alexanderwu3a1q5;
import javax.swing.*;
import java.awt.*;

/**
 *
 * @author weia7993
 */
public class AlexanderWU3A1Q5 extends JFrame {

    /**
     * @param args the command line arguments
     */
    
    public AlexPanel panel = new AlexPanel();
    
    public static void main(String[] args) {
        // TODO code application logic here
        AlexanderWU3A1Q5 frame = new AlexanderWU3A1Q5(); // create new frame
        frame.createGUI(); // create GUI
    }
    
    private void createGUI() { // create frame
        setTitle("Name Sorter"); // sets title
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // closes application when exit button clicked
        setPreferredSize(new Dimension(840, 550)); // sets dimensions for frame
        setResizable(false);  // not resizable

        add(panel); // add custom JPanel to frame

        pack();
        setVisible(true); // sets frame visible
    }
    
}
