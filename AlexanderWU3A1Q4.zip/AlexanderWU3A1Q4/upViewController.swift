//
//  upViewController.swift
//  AlexanderWU3A1Q4
//
//  Created by Sissi Wei on 2019-05-19.
//  Copyright © 2019 Alex. All rights reserved.
//

import UIKit

class upViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func toQuizTop(_ sender: Any) { // proceeds to quiz
        performSegue(withIdentifier: "topToQuiz", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
