//
//  rightQuizController.swift
//  AlexanderWU3A1Q4
//
//  Created by Sissi Wei on 2019-05-19.
//  Copyright © 2019 Alex. All rights reserved.
//

import UIKit

class rightQuizController: UIViewController {
    
    var answeredCorrectly = false // boolean to check if question is answered correctly
    @IBOutlet weak var correct: UILabel!
    @IBOutlet weak var incorrect: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func pickedCow(_ sender: Any) { // user picked cow, incorrect
        incorrect.isHidden = false
        correct.isHidden = true
        answeredCorrectly = false
    }
    
    @IBAction func pickedDog(_ sender: Any) { // user picked dog, incorrect
        incorrect.isHidden = false
        correct.isHidden = true
        answeredCorrectly = false
    }
    
    @IBAction func pickedBird(_ sender: Any) { // user picked bird, correct
        incorrect.isHidden = true
        correct.isHidden = false
        answeredCorrectly = true
    }
    
    @IBAction func toHome(_ sender: Any) { // returns to home if question is answered correctly
        if answeredCorrectly == true {
            performSegue(withIdentifier: "rightToHome", sender: self)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
