//
//  downQuizController.swift
//  AlexanderWU3A1Q4
//
//  Created by Sissi Wei on 2019-05-20.
//  Copyright © 2019 Alex. All rights reserved.
//

import UIKit

class downQuizController: UIViewController {
    
    var answeredCorrectly = false // define boolean that allows proceeding
    
    @IBOutlet weak var correct: UILabel!
    
    @IBAction func toHome(_ sender: Any) { // button to return to home
        if answeredCorrectly == true {
            performSegue(withIdentifier: "downToHome", sender: self)
        }
    }
    
    override func viewDidLoad() { // create a swipe gesture recognizer
        super.viewDidLoad()
        
        let swipe = UISwipeGestureRecognizer(target: self, action:#selector(handleGesture(_:)))
        swipe.direction = .down
        view.addGestureRecognizer(swipe)

        // Do any additional setup after loading the view.
    }
    
    @objc func handleGesture(_ sender:UISwipeGestureRecognizer) { // if gesture is performed, allow user to proceed
        if sender.direction == .down {
            answeredCorrectly = true
            correct.isHidden = false
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
