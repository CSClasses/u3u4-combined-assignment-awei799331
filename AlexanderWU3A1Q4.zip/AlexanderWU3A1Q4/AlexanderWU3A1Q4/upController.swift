//
//  upController.swift
//  AlexanderWU3A1Q4
//
//  Created by Sissi Wei on 2019-05-19.
//  Copyright © 2019 Alex. All rights reserved.
//

import UIKit

class upController: NSObject {

}
