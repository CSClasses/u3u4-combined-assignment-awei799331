//
//  leftQuizController.swift
//  AlexanderWU3A1Q4
//
//  Created by Sissi Wei on 2019-05-20.
//  Copyright © 2019 Alex. All rights reserved.
//

import UIKit

class leftQuizController: UIViewController {
    
    var answeredCorrectly = false

    @IBOutlet weak var correct: UILabel!
    @IBOutlet weak var incorrect: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goAway(_ sender: Any) { // user clicked go away, correct
        answeredCorrectly = true
        correct.isHidden = false
        incorrect.isHidden = true
    }
    
    @IBAction func sleep(_ sender: Any) { // user clicked sleep, incorrect
        answeredCorrectly = false
        correct.isHidden = true
        incorrect.isHidden = false
    }
    
    @IBAction func `continue`(_ sender: Any) { // user clicked continue, incorrect
        answeredCorrectly = false
        correct.isHidden = true
        incorrect.isHidden = false
    }
    
    @IBAction func toHome(_ sender: Any) { // return to home with segue
        if answeredCorrectly == true {
            performSegue(withIdentifier: "leftToHome", sender: self)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
