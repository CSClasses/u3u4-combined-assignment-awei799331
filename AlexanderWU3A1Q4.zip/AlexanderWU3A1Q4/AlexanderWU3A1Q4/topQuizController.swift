//
//  topQuizController.swift
//  AlexanderWU3A1Q4
//
//  Created by Sissi Wei on 2019-05-19.
//  Copyright © 2019 Alex. All rights reserved.
//

import UIKit

class topQuizController: UIViewController {
    
    var answeredCorrectly = false
    
    @IBOutlet weak var incorrect: UILabel!
    @IBOutlet weak var correct: UILabel!
    @IBOutlet weak var balloonTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func toHome(_ sender: Any) { // button that returns to home when answered correctly
        if answeredCorrectly == true {
            print(answeredCorrectly)
            performSegue(withIdentifier: "topToHome", sender: self)
        }
    }
    
    @IBAction func answerSubmitted(_ sender: Any) { // submitted an answer with text field and button
        if balloonTextField.text != "" {
            let answer = balloonTextField.text!
            if answer != "balloon" { // answer is balloon
                answeredCorrectly = false
                correct.isHidden = true
                incorrect.isHidden = false
            } else { // not balloon
                correct.isHidden = false
                incorrect.isHidden = true
                answeredCorrectly = true
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
