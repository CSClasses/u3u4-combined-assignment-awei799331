//
//  leftViewController.swift
//  AlexanderWU3A1Q4
//
//  Created by Sissi Wei on 2019-05-20.
//  Copyright © 2019 Alex. All rights reserved.
//

import UIKit

class leftViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func toLeftQuiz(_ sender: Any) { // button goes to quiz
        performSegue(withIdentifier: "leftToQuiz", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
