//
//  ICS4UI
//  AlexanderWU3A1Q4
//  May 20th, 2019
//
//  ViewController.swift
//  AlexanderWU3A1Q4
//
//  Created by Alexander Wei on 2019-05-18.
//  Copyright © 2019 Alex. All rights reserved.
//

/*
 Arrow PNGs link: https://www.flaticon.com/packs/arrows-41
 Dirt image: https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjS962wnqviAhUK2VkKHbNsCegQjRx6BAgBEAU&url=https%3A%2F%2Fmedium.com%2F%40buster%2Fdirt-f6907b34548f&psig=AOvVaw1w0SE21_GG9DtAYOo_6cfo&ust=1558480484885520
 Bird image: https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjv3fTjnqviAhWBtlkKHY3eB74QjRx6BAgBEAU&url=https%3A%2F%2Flafeber.com%2Fpet-birds%2Fspecies%2Fcockatiel%2F&psig=AOvVaw3ggdj8jSp-J7o4BFD3UEyo&ust=1558480541746823
 Balloon image:
 https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjAmaiBn6viAhWxrVkKHcp7CRYQjRx6BAgBEAU&url=http%3A%2F%2Fdominicanballoons.com%2Fproduct%2Fcaribbean-sunrise%2F&psig=AOvVaw3iGTmcz9_1I9eiCjBwIsVs&ust=1558480645694560
 Wrong way sign: https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwjikMXrn6viAhXMxVkKHXdpBGMQjRx6BAgBEAU&url=https%3A%2F%2Fwww.seton.com%2Fwrong-way-signs-sp28.html&psig=AOvVaw2nYQNx6lpMbzG1ipTgEaM7&ust=1558480862398965
 */

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // initializes buttons that segue to a photo upon press
    
    @IBAction func clickDown(_ sender: Any) {
        performSegue(withIdentifier: "toDown", sender: self)
    }
    
    @IBAction func clickRight(_ sender: Any) {
        performSegue(withIdentifier: "toRight", sender: self)
    }
    
    @IBAction func clickTop(_ sender: Any) {
        performSegue(withIdentifier: "toTop", sender: self)
    }
    
    @IBAction func clickLeft(_ sender: Any) {
        performSegue(withIdentifier: "toLeft", sender: self)
    }
    
    @IBAction func clickedExit(_ sender: Any) {
        exit(0)
    }
}

