import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*; // import libraries


public class AlexanderWU3A1Q1 {

    public static void main(String[] args) { // main method
        JFrame frame = new JFrame(); // makes new frame object
        frame.setTitle("Drawing Tool"); // sets title
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // closes application when exit button clicked
        frame.setPreferredSize(new Dimension(750, 400)); // sets dimensions for frame
        frame.setResizable(false);  // not resizable

        JPanel panel = new JPanel(); // create new panel
        panel.setLayout(null);

        ArrayList<ArrayList<String> > array = new ArrayList<>(); // take input
        try (Scanner scanner = new Scanner(new File("eng-climate-summaries-All-4,2018.csv"));) { // read file into scanner
            while (scanner.hasNext()) {
                array.add(parseThings(scanner.nextLine()));
            }
        } catch (Exception FileNotFoundException) {
        }

        ArrayList<String> stationNames = new ArrayList<>(); // make arraylist of the city names
        for (int i = 32; i < 1114; i++) {
            String e = array.get(i).get(0); // read from 2D array
            stationNames.add(e);
        }
        Vector<String> stationNamesArray = new Vector<>(stationNames); // convert arraylist into vector for JComboBox

        JComboBox chooseLocation = new JComboBox(stationNamesArray); // initialize JComboBox
        chooseLocation.setEditable(false);

        ArrayList<String> Queries = new ArrayList<>(); // create list of queries that can be made
        for (int i = 5; i < 29; i++) {
            Queries.add(array.get(i).get(1));
        }
        Vector<String> QueriesVector = new Vector<>(Queries); // convert arraylist into vector

        JComboBox chooseQuery = new JComboBox(QueriesVector); // create JComboBox
        chooseQuery.setEditable(false);

        JLabel queryAnswer = new JLabel("", JLabel.CENTER); // create JLabels to display information
        JLabel note = new JLabel("NOTE: if you searched and \'NA\' or nothing appears, this means there is no data for the specific query.", JLabel.CENTER);

        JButton QueryButton = new JButton("Start Query"); // add a query button and an action listener
        QueryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                int cityQuery = chooseLocation.getSelectedIndex(); // get values
                int dataQuery = chooseQuery.getSelectedIndex();
                String answer = array.get(cityQuery + 32).get(dataQuery + 1); // read 2D array
                queryAnswer.setText("Query: " + answer);
            }
        });
        chooseLocation.setBounds(10, 10, 350, 30); // set locations and add objects to the panel
        panel.add(chooseLocation);
        chooseQuery.setBounds(370, 10, 350, 30);
        panel.add(chooseQuery);
        QueryButton.setBounds(325, 50, 100, 30);
        panel.add(QueryButton);
        queryAnswer.setBounds(0, 90, 750, 30);
        panel.add(queryAnswer);
        note.setBounds(0, 335, 750, 30);
        panel.add(note);
        frame.add(panel); // add JPanel to frame
        frame.pack();
        frame.setVisible(true); // sets frame visible

    }

    private static ArrayList<String> parseThings(String Line) { // method for parsing the string for reading inputs
        ArrayList<String> lines = new ArrayList<>();
        try (Scanner scanRows = new Scanner(Line)) {
            scanRows.useDelimiter(","); // split the items into arrayList
            while (scanRows.hasNext()) {
                String temp = scanRows.next();
                try {
                    temp = temp.substring(1, temp.length() - 1); // each entry/string has double quotes around it, remove these
                lines.add(temp);
                } catch (Exception e) {} // exception if the string is empty
            }
        }
        return lines; // return the arrayList
    }

}